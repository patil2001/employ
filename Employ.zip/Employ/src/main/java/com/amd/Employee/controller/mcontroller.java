package com.amd.Employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import com.amd.Employee.entity.Employee;

import com.amd.Employee.service.EmployeeserviceImp1;
@RestController
public class mcontroller {
	@Autowired
	private EmployeeserviceImp1 employeeservs;
	
	
	public mcontroller(EmployeeserviceImp1 employeeservs) {
		
		this.employeeservs = employeeservs;
	}
	@PostMapping("/add")
	public String add(@RequestBody Employee emp) {
		employeeservs.saveEmployee(emp);
		return "Employee added successfully";
		
	}
	@GetMapping("/getAll")
	public List<Employee>getAllEmployee(){
		return employeeservs.getAllEmployee();
	}
	@PutMapping("/update")
	public Employee updEmployee(@RequestBody Employee employee)
	{
		return employeeservs.updateEmployee(employee);
	}
	@DeleteMapping("/delete")
	public void delEmployee(@RequestBody Employee employee)
	{
		employeeservs.deleteEmployee(employee);
	}
	

}
