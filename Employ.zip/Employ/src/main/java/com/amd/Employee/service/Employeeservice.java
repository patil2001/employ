package com.amd.Employee.service;

import java.util.List;

import com.amd.Employee.entity.Employee;
import com.amd.Employee.entity.Employee;

public interface Employeeservice {

	public Employee saveEmployee(Employee employee);
	public List<Employee> getAllEmployee() ;
	public void deleteEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
	
}
