package com.amd.Employee.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amd.Employee.entity.Employee;
import com.amd.Employee.repo.EmployeeRepo;
import com.amd.Employee.entity.Employee;
import com.amd.Employee.repo.EmployeeRepo;

@Service
public class EmployeeserviceImp1 implements Employeeservice {
	@Autowired
	private EmployeeRepo employeerepo;
	
	public EmployeeserviceImp1(EmployeeRepo EmployeeRepo) {
		
		this.employeerepo = EmployeeRepo;
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeerepo.save(employee);
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeerepo.findAll();
	}

	@Override
	public void deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeerepo.delete(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeerepo.save(employee);
	}

		
	}
	


